package com.example.webshop.repositories;

public interface placeholder {
}
